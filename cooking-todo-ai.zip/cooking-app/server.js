import express from "express";
import Anthropic from "@anthropic-ai/sdk";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// JSON schema we ask the model to fill. Keeping the contract explicit
// makes the response safe to parse and easy to map onto the UI.
const SYSTEM_PROMPT = `You are a practical home-cooking planner. You take a person's day and
constraints and produce a structured, realistic cooking to-do list.

You MUST respond with ONLY a valid JSON object, no markdown, no backticks, no preamble.
Use this exact shape:

{
  "summary": "one short sentence describing the plan for the day",
  "meals": [
    {
      "slot": "Breakfast" | "Lunch" | "Dinner" | "Snack",
      "name": "dish name",
      "prepMinutes": number,
      "steps": ["short actionable step", "..."],
      "ingredients": [{ "item": "name", "quantity": "e.g. 200 g", "estCost": number }]
    }
  ],
  "grocery": [
    { "item": "name", "quantity": "total needed", "estCost": number, "have": false }
  ],
  "substitutions": [
    { "ingredient": "original", "swap": "cheaper/available alternative", "reason": "why" }
  ],
  "budget": {
    "currency": "INR",
    "estimatedTotal": number,
    "limit": number,
    "feasible": true | false,
    "verdict": "one sentence on whether the plan fits the budget and what to cut if not"
  }
}

Rules:
- estCost and estimatedTotal are numbers only (no currency symbols).
- Honour the diet, time available, skill level, servings and budget the user gives.
- If the plan exceeds budget, set feasible=false and use substitutions to bring it down,
  and explain the trade-off in budget.verdict.
- Keep steps short and imperative. Quantities should be realistic for the servings count.`;

app.post("/api/plan", async (req, res) => {
  try {
    const {
      day = "",
      meals = ["Breakfast", "Lunch", "Dinner"],
      diet = "no restrictions",
      servings = 2,
      timeAvailable = "moderate",
      skill = "intermediate",
      budget = 0,
      currency = "INR",
      pantry = "",
    } = req.body || {};

    const userMessage = `Plan my cooking to-do list.

Describe of my day / mood / what I feel like eating: ${day || "a normal day, surprise me"}
Meals to plan: ${meals.join(", ")}
Diet: ${diet}
Servings: ${servings}
Time available for cooking: ${timeAvailable}
Cooking skill: ${skill}
Budget limit: ${budget > 0 ? `${budget} ${currency}` : "flexible"}
Currency: ${currency}
Already in my pantry (don't add these to grocery list): ${pantry || "nothing specified"}

Return ONLY the JSON object described in the system prompt.`;

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 2000,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }],
    });

    const text = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .replace(/```json|```/g, "")
      .trim();

    let plan;
    try {
      plan = JSON.parse(text);
    } catch {
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start === -1 || end === -1) throw new Error("Model did not return JSON");
      plan = JSON.parse(text.slice(start, end + 1));
    }

    res.json({ ok: true, plan });
  } catch (err) {
    console.error("Plan generation failed:", err);
    res.status(500).json({
      ok: false,
      error: "Couldn't build a plan right now. Check the inputs and try again.",
    });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`Cooking to-do AI running on http://localhost:${PORT}`);
});
