# Mise — AI Cooking To-Do List

A simple Node.js + Express web app that turns a description of your day into a
structured cooking plan, powered by Claude.

## Features

- **Day-based meal planning** — describe your day/mood; it plans Breakfast / Lunch / Dinner / Snack
- **Ordered cooking to-do list** — each meal gets checkable, imperative steps with prep time
- **Grocery list** — consolidated items with quantities and per-item cost estimates
- **Substitutions** — cheaper or more available swaps with the reason for each
- **Budget feasibility logic** — total vs. your limit, a feasible/over verdict, and what to cut
- Diet, servings, time-available, skill level, currency, and pantry ("already have") inputs
- Pantry items are excluded from the grocery list
- Responsive, keyboard-accessible UI; interactive step checkboxes

## Setup

```bash
npm install
cp .env.example .env        # then put your real ANTHROPIC_API_KEY in .env
npm start
```

Open http://localhost:3000

## How it works

`server.js` exposes `POST /api/plan`. It sends your inputs to Claude with a strict
JSON-only system prompt, parses the response, and returns it. The frontend
(`public/index.html`) renders the plan into meal cards, a grocery table, substitution
notes, and a budget panel.

- Model: `claude-sonnet-4-6`
- The system prompt fixes the JSON shape, so the response maps cleanly onto the UI.
- Parsing is defensive: strips code fences and falls back to extracting the `{...}` block.

## Project structure

```
cooking-app/
├── server.js          Express server + Claude call + JSON parsing
├── package.json
├── .env.example
└── public/
    └── index.html     Single-page UI (HTML + CSS + JS)
```
